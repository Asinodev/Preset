const fs = require('fs');
let code = fs.readFileSync('app.js', 'utf8');

// 1. Add APK_DOWNLOAD_URL
const guideTarget = `const GUIDE_VIDEO_SOURCE = '';`;
const guideReplacement = `const GUIDE_VIDEO_SOURCE = '';

  // Configurable Android APK Download URL
  // Creator can replace this with their direct hosted APK release link
  const APK_DOWNLOAD_URL = 'https://github.com/asino-presets/releases/download/v1.0/Asino_Official.apk';`;

if (code.includes(guideTarget)) {
  code = code.replace(guideTarget, guideReplacement);
}

// 2. Add I18N entries
const idTarget = `creatorChannelBtn: 'Saluran WhatsApp'`;
const idReplacement = `creatorChannelBtn: 'Saluran WhatsApp',
      downloadApk: 'Download',
      downloadApkToast: 'Memulai unduhan file Asino Official APK untuk Android...'`;
if (code.includes(idTarget)) {
  code = code.replace(idTarget, idReplacement);
}

const enTarget = `creatorChannelBtn: 'WhatsApp Channel'`;
const enReplacement = `creatorChannelBtn: 'WhatsApp Channel',
      downloadApk: 'Download',
      downloadApkToast: 'Starting Asino Official APK download for Android...'`;
if (code.includes(enTarget)) {
  code = code.replace(enTarget, enReplacement);
}

const jaTarget = `creatorChannelBtn: 'WhatsAppチャンネル'`;
const jaReplacement = `creatorChannelBtn: 'WhatsAppチャンネル',
      downloadApk: 'ダウンロード',
      downloadApkToast: 'Android専用Asino公式APKのダウンロードを開始しています...'`;
if (code.includes(jaTarget)) {
  code = code.replace(jaTarget, jaReplacement);
}

// 3. Add modal functions
const aboutModalTarget = `  function openAboutModal() {`;
const modalFuncs = `  function triggerApkDownload() {
    showToast(I18N[state.activeLang]?.downloadApkToast || 'Memulai unduhan Asino Official APK...');
    const a = document.createElement('a');
    a.href = APK_DOWNLOAD_URL;
    a.download = 'Asino_Official.apk';
    a.target = '_blank';
    a.rel = 'noopener noreferrer';
    document.body.appendChild(a);
    a.click();
    setTimeout(() => {
      if (document.body.contains(a)) document.body.removeChild(a);
    }, 100);
  }

  function openApkModal() {
    const modal = document.getElementById('apk-modal');
    if (modal) {
      modal.hidden = false;
      modal.setAttribute('aria-hidden', 'false');
    }
  }

  function closeApkModal() {
    const modal = document.getElementById('apk-modal');
    if (modal) {
      modal.hidden = true;
      modal.setAttribute('aria-hidden', 'true');
    }
  }

  function openAboutModal() {`;
if (code.includes(aboutModalTarget)) {
  code = code.replace(aboutModalTarget, modalFuncs);
}

// 4. Add event listeners
const aboutBtnTarget = `    // About modal trigger
    const openAboutBtn = document.getElementById('open-about-btn');`;

const listenersAddition = `    // Android APK Download Button (Header & Popup)
    const downloadApkBtn = document.getElementById('download-apk-btn');
    if (downloadApkBtn) {
      downloadApkBtn.addEventListener('click', (e) => {
        e.preventDefault();
        const isAndroid = /Android/i.test(navigator.userAgent);
        if (isAndroid) {
          triggerApkDownload();
        }
        openApkModal();
      });
    }

    const popupDownloadApkBtn = document.getElementById('popup-download-apk-btn');
    if (popupDownloadApkBtn) {
      popupDownloadApkBtn.addEventListener('click', () => {
        const morePopup = document.getElementById('more-popup');
        if (morePopup) morePopup.hidden = true;
        openApkModal();
        triggerApkDownload();
      });
    }

    const apkCloseBtn = document.getElementById('apk-close-btn');
    if (apkCloseBtn) apkCloseBtn.addEventListener('click', closeApkModal);

    const modalCancelBtn = document.getElementById('modal-cancel-btn');
    if (modalCancelBtn) modalCancelBtn.addEventListener('click', closeApkModal);

    const modalStartDownloadBtn = document.getElementById('modal-start-download-btn');
    if (modalStartDownloadBtn) {
      modalStartDownloadBtn.href = APK_DOWNLOAD_URL;
      modalStartDownloadBtn.addEventListener('click', (e) => {
        e.preventDefault();
        triggerApkDownload();
      });
    }

    // About modal trigger
    const openAboutBtn = document.getElementById('open-about-btn');`;

if (code.includes(aboutBtnTarget)) {
  code = code.replace(aboutBtnTarget, listenersAddition);
}

// 5. Add escape key handler for apk-modal
const escTarget = `} else if (!document.getElementById('about-modal').hidden) {
          closeAboutModal();`;

const escReplacement = `} else if (!document.getElementById('apk-modal')?.hidden) {
          closeApkModal();
        } else if (!document.getElementById('about-modal').hidden) {
          closeAboutModal();`;

if (code.includes(escTarget)) {
  code = code.replace(escTarget, escReplacement);
}

fs.writeFileSync('app.js', code, 'utf8');
console.log('APP.JS UPDATED SUCCESSFULLY');
